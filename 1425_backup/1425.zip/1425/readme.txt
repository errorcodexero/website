1425 is a responsive, highly customizable theme.

Theme instructions can be found at http://templateexpress.com/adam/documentation/

Changelog
--------------------------------------------

Version: 2.4
* Fixed issue with child themes
* Fixed text domain issues

Version: 2.2

* Improved documentation
* Added option for Favicon & App Icons
* Added options for contact details to be displayed in header
* Added options to add social icons to header
* Added options to control the footer
* Added option to pick your own color scheme
* Added more options for homepage slider
* Added more options for homepage service section
* Added more options for homepage recent posts section
* Added options to display users by selecting Id's for authors template
* Replaced Genericons with FontAwesome icon fonts


Font
-------------------------------------------
FontAwesome
vector icons embedded in a webfont designed to be clean and simple 
keeping with a generic aesthetic.
More info at http://fortawesome.github.io/Font-Awesome/

Open Sans
This Font Software is licensed under the Apache License v2.00
More info available with at http://www.apache.org/licenses/

License
--------------------------------------------
License: GNU General Public License v2.0
License URI: ?http://www.gnu.org/licenses/gpl-2.0.html
